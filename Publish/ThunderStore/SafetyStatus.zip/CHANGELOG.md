<table>
	<tbody>
		<tr>
			<th align="center">Version</th>
			<th align="center">Notes</th>
		</tr>
		<tr>
			<td align="center">1.1.0</td>
			<td align="left">
				<ul>
					<li>Updated for Ashlands release.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.1</td>
			<td align="left">
				<ul>
					<li>Future proofing against Valheim updates.</li>
					<li>Update Jotunn version.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.0</td>
			<td align="left">
				<ul>
					<li>Initial release.</li>
				</ul>
			</td>
		</tr>
	</tbody>
</table>
