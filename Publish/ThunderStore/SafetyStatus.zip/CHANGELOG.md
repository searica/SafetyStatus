<table>
	<tbody>
		<tr>
			<th align="center">Version</th>
			<th align="center">Notes</th>
		</tr>
		<tr>
			<td align="center">1.3.3</td>
			<td align="left">
				<ul>
					<li>Dev build to test out a possible fix for a rare network send error in multiplayer.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.3.2</td>
			<td align="left">
				<ul>
					<li>Reduced number of network requests in multiplayer.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.3.1</td>
			<td align="left">
				<ul>
					<li>Fixed status effect being applied to tamed creatures and exacerbating lag on servers.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.3.0</td>
			<td align="left">
				<ul>
					<li>Updated for Deep North release!</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.2.2</td>
			<td align="left">
				<ul>
					<li>Updated Jotunn.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.2.1</td>
			<td align="left">
				<ul>
					<li>Fixed a bug that occured when a non-player character died within range of a player base effect.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.2.0</td>
			<td align="left">
				<ul>
					<li>Updated for Bog Witch release.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.1.0</td>
			<td align="left">
				<ul>
					<li>Updated for Ashlands release.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.1</td>
			<td align="left">
				<ul>
					<li>Future proofing against Valheim updates.</li>
					<li>Update Jotunn version.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.0</td>
			<td align="left">
				<ul>
					<li>Initial release.</li>
				</ul>
			</td>
		</tr>
	</tbody>
</table>
